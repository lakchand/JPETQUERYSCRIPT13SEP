Action()
{

	web_set_sockets_option("SSL_VERSION", "TLS1.2");

	web_url("catalog", 
		"URL=https://jpetstore.cfapps.io/catalog", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t1.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=/favicon.ico", "Referer=", ENDITEM, 
		LAST);

	lr_start_transaction("Sign in transaction");

	web_add_cookie("SRCHUID=V=2&GUID=A6AEF90CC96344DAA0D331AAB28C50F6&dmnchg=1; DOMAIN=iecvlist.microsoft.com");

	web_add_cookie("SRCHD=AF=NOFORM; DOMAIN=iecvlist.microsoft.com");

	web_add_cookie("MC1=GUID=d93005dada154aa6a984828a2eac10f9&HASH=d930&LV=201908&V=4&LU=1565772800870; DOMAIN=iecvlist.microsoft.com");

	web_add_cookie("MUID=0E74AE4A1B9368B81B2FA3F21F936B3C; DOMAIN=iecvlist.microsoft.com");

	web_add_cookie("SRCHUSR=DOB=20190813; DOMAIN=iecvlist.microsoft.com");

	lr_think_time(17);

	web_link("Sign In", 
		"Text=Sign In", 
		"Snapshot=t2.inf", 
		EXTRARES, 
		"Url=/favicon.ico", "Referer=", ENDITEM, 
		"Url=https://iecvlist.microsoft.com/ie11blocklist/1401746408/versionlist.xml", "Referer=", ENDITEM, 
		LAST);

	lr_end_transaction("Sign in transaction",LR_AUTO);

	web_reg_find("Text=Welcome", 
		LAST);

	web_submit_form("login", 
		"Snapshot=t3.inf", 
		ITEMDATA, 
		"Name=username", "Value=user1", ENDITEM, 
		"Name=password", "Value=animals$123", ENDITEM, 
		EXTRARES, 
		"Url=/favicon.ico", "Referer=", ENDITEM, 
		LAST);

	/* Welcome page for the application */

	lr_think_time(74);

	lr_start_transaction("Selecting the products");

	web_image("sm_fish.gif", 
		"Src=/images/sm_fish.gif", 
		"Snapshot=t4.inf", 
		EXTRARES, 
		"Url=/favicon.ico", "Referer=", ENDITEM, 
		LAST);

	lr_think_time(24);

	lr_start_transaction("Fish Transactions");

	web_link("FI-SW-01", 
		"Text=FI-SW-01", 
		"Snapshot=t5.inf", 
		EXTRARES, 
		"Url=/favicon.ico", "Referer=", ENDITEM, 
		LAST);

	web_link("Add to Cart", 
		"Text=Add to Cart", 
		"Ordinal=1", 
		"Snapshot=t6.inf", 
		EXTRARES, 
		"Url=/favicon.ico", "Referer=", ENDITEM, 
		LAST);

	lr_think_time(5);

	web_link("Return to Main Menu", 
		"Text=Return to Main Menu", 
		"Snapshot=t7.inf", 
		EXTRARES, 
		"Url=/favicon.ico", "Referer=", ENDITEM, 
		LAST);

	web_image("sm_fish.gif_2", 
		"Src=/images/sm_fish.gif", 
		"Snapshot=t8.inf", 
		EXTRARES, 
		"Url=/favicon.ico", "Referer=", ENDITEM, 
		LAST);

	web_link("FI-SW-01_2", 
		"Text=FI-SW-01", 
		"Snapshot=t9.inf", 
		EXTRARES, 
		"Url=/favicon.ico", "Referer=", ENDITEM, 
		LAST);

	web_link("Add to Cart_2", 
		"Text=Add to Cart", 
		"Ordinal=2", 
		"Snapshot=t10.inf", 
		EXTRARES, 
		"Url=/favicon.ico", "Referer=", ENDITEM, 
		LAST);

	web_link("Return to Main Menu_2", 
		"Text=Return to Main Menu", 
		"Snapshot=t11.inf", 
		EXTRARES, 
		"Url=/favicon.ico", "Referer=", ENDITEM, 
		LAST);

	web_image("sm_fish.gif_3", 
		"Src=/images/sm_fish.gif", 
		"Snapshot=t12.inf", 
		EXTRARES, 
		"Url=/favicon.ico", "Referer=", ENDITEM, 
		LAST);

	web_link("FI-SW-02", 
		"Text=FI-SW-02", 
		"Snapshot=t13.inf", 
		EXTRARES, 
		"Url=/favicon.ico", "Referer=", ENDITEM, 
		LAST);

	web_link("Add to Cart_3", 
		"Text=Add to Cart", 
		"Snapshot=t14.inf", 
		EXTRARES, 
		"Url=/favicon.ico", "Referer=", ENDITEM, 
		LAST);

	web_submit_form("cart", 
		"Snapshot=t15.inf", 
		ITEMDATA, 
		"Name=lines[0].quantity", "Value=1", ENDITEM, 
		"Name=lines[1].quantity", "Value=1", ENDITEM, 
		"Name=lines[2].quantity", "Value=1", ENDITEM, 
		"Name=update", "Value=Update Cart", ENDITEM, 
		EXTRARES, 
		"Url=/favicon.ico", "Referer=", ENDITEM, 
		LAST);

	web_link("Return to Main Menu_3", 
		"Text=Return to Main Menu", 
		"Snapshot=t16.inf", 
		EXTRARES, 
		"Url=/favicon.ico", "Referer=", ENDITEM, 
		LAST);

	web_image("sm_fish.gif_4", 
		"Src=/images/sm_fish.gif", 
		"Snapshot=t17.inf", 
		EXTRARES, 
		"Url=/favicon.ico", "Referer=", ENDITEM, 
		LAST);

	web_link("FI-FW-01", 
		"Text=FI-FW-01", 
		"Snapshot=t18.inf", 
		EXTRARES, 
		"Url=/favicon.ico", "Referer=", ENDITEM, 
		LAST);

	web_link("Add to Cart_4", 
		"Text=Add to Cart", 
		"Ordinal=1", 
		"Snapshot=t19.inf", 
		EXTRARES, 
		"Url=/favicon.ico", "Referer=", ENDITEM, 
		LAST);

	web_link("Return to Main Menu_4", 
		"Text=Return to Main Menu", 
		"Snapshot=t20.inf", 
		EXTRARES, 
		"Url=/favicon.ico", "Referer=", ENDITEM, 
		LAST);

	web_image("sm_fish.gif_5", 
		"Src=/images/sm_fish.gif", 
		"Snapshot=t21.inf", 
		EXTRARES, 
		"Url=/favicon.ico", "Referer=", ENDITEM, 
		LAST);

	web_link("FI-FW-02", 
		"Text=FI-FW-02", 
		"Snapshot=t22.inf", 
		EXTRARES, 
		"Url=/favicon.ico", "Referer=", ENDITEM, 
		LAST);

	web_link("Add to Cart_5", 
		"Text=Add to Cart", 
		"Ordinal=2", 
		"Snapshot=t23.inf", 
		EXTRARES, 
		"Url=/favicon.ico", "Referer=", ENDITEM, 
		LAST);

	lr_think_time(4);

	web_link("Return to Main Menu_5", 
		"Text=Return to Main Menu", 
		"Snapshot=t24.inf", 
		EXTRARES, 
		"Url=/favicon.ico", "Referer=", ENDITEM, 
		LAST);

	web_image("sm_fish.gif_6", 
		"Src=/images/sm_fish.gif", 
		"Snapshot=t25.inf", 
		EXTRARES, 
		"Url=/favicon.ico", "Referer=", ENDITEM, 
		LAST);

	web_link("FI-FW-02_2", 
		"Text=FI-FW-02", 
		"Snapshot=t26.inf", 
		EXTRARES, 
		"Url=/favicon.ico", "Referer=", ENDITEM, 
		LAST);

	web_link("Add to Cart_6", 
		"Text=Add to Cart", 
		"Ordinal=1", 
		"Snapshot=t27.inf", 
		EXTRARES, 
		"Url=/favicon.ico", "Referer=", ENDITEM, 
		LAST);

	lr_end_transaction("Fish Transactions",LR_AUTO);

	lr_think_time(14);

	web_link("Return to Main Menu_6", 
		"Text=Return to Main Menu", 
		"Snapshot=t28.inf", 
		EXTRARES, 
		"Url=/favicon.ico", "Referer=", ENDITEM, 
		LAST);

	lr_think_time(10);

	lr_start_transaction("Dogs Transaction");

	web_image("sm_dogs.gif", 
		"Src=/images/sm_dogs.gif", 
		"Snapshot=t29.inf", 
		EXTRARES, 
		"Url=/favicon.ico", "Referer=", ENDITEM, 
		LAST);

	web_link("K9-BD-01", 
		"Text=K9-BD-01", 
		"Snapshot=t30.inf", 
		EXTRARES, 
		"Url=/favicon.ico", "Referer=", ENDITEM, 
		LAST);

	web_link("Add to Cart_7", 
		"Text=Add to Cart", 
		"Ordinal=1", 
		"Snapshot=t31.inf", 
		EXTRARES, 
		"Url=/favicon.ico", "Referer=", ENDITEM, 
		LAST);

	web_submit_form("cart_2", 
		"Snapshot=t32.inf", 
		ITEMDATA, 
		"Name=lines[0].quantity", "Value=1", ENDITEM, 
		"Name=lines[1].quantity", "Value=1", ENDITEM, 
		"Name=lines[2].quantity", "Value=1", ENDITEM, 
		"Name=lines[3].quantity", "Value=1", ENDITEM, 
		"Name=lines[4].quantity", "Value=1", ENDITEM, 
		"Name=lines[5].quantity", "Value=1", ENDITEM, 
		"Name=lines[6].quantity", "Value=1", ENDITEM, 
		"Name=update", "Value=Update Cart", ENDITEM, 
		EXTRARES, 
		"Url=/favicon.ico", "Referer=", ENDITEM, 
		LAST);

	web_link("Return to Main Menu_7", 
		"Text=Return to Main Menu", 
		"Snapshot=t33.inf", 
		EXTRARES, 
		"Url=/favicon.ico", "Referer=", ENDITEM, 
		LAST);

	web_image("sm_dogs.gif_2", 
		"Src=/images/sm_dogs.gif", 
		"Snapshot=t34.inf", 
		EXTRARES, 
		"Url=/favicon.ico", "Referer=", ENDITEM, 
		LAST);

	web_link("K9-BD-01_2", 
		"Text=K9-BD-01", 
		"Snapshot=t35.inf", 
		EXTRARES, 
		"Url=/favicon.ico", "Referer=", ENDITEM, 
		LAST);

	web_link("Add to Cart_8", 
		"Text=Add to Cart", 
		"Ordinal=2", 
		"Snapshot=t36.inf", 
		EXTRARES, 
		"Url=/favicon.ico", "Referer=", ENDITEM, 
		LAST);

	web_link("Return to Main Menu_8", 
		"Text=Return to Main Menu", 
		"Snapshot=t37.inf", 
		EXTRARES, 
		"Url=/favicon.ico", "Referer=", ENDITEM, 
		LAST);

	web_image("sm_dogs.gif_3", 
		"Src=/images/sm_dogs.gif", 
		"Snapshot=t38.inf", 
		EXTRARES, 
		"Url=/favicon.ico", "Referer=", ENDITEM, 
		LAST);

	web_link("K9-PO-02", 
		"Text=K9-PO-02", 
		"Snapshot=t39.inf", 
		EXTRARES, 
		"Url=/favicon.ico", "Referer=", ENDITEM, 
		LAST);

	web_link("Add to Cart_9", 
		"Text=Add to Cart", 
		"Snapshot=t40.inf", 
		EXTRARES, 
		"Url=/favicon.ico", "Referer=", ENDITEM, 
		LAST);

	web_link("Return to Main Menu_9", 
		"Text=Return to Main Menu", 
		"Snapshot=t41.inf", 
		EXTRARES, 
		"Url=/favicon.ico", "Referer=", ENDITEM, 
		LAST);

	web_image("sm_dogs.gif_4", 
		"Src=/images/sm_dogs.gif", 
		"Snapshot=t42.inf", 
		EXTRARES, 
		"Url=/favicon.ico", "Referer=", ENDITEM, 
		LAST);

	web_link("K9-DL-01", 
		"Text=K9-DL-01", 
		"Snapshot=t43.inf", 
		EXTRARES, 
		"Url=/favicon.ico", "Referer=", ENDITEM, 
		LAST);

	web_link("Add to Cart_10", 
		"Text=Add to Cart", 
		"Ordinal=1", 
		"Snapshot=t44.inf", 
		EXTRARES, 
		"Url=/favicon.ico", "Referer=", ENDITEM, 
		LAST);

	web_link("Return to Main Menu_10", 
		"Text=Return to Main Menu", 
		"Snapshot=t45.inf", 
		EXTRARES, 
		"Url=/favicon.ico", "Referer=", ENDITEM, 
		LAST);

	web_image("sm_dogs.gif_5", 
		"Src=/images/sm_dogs.gif", 
		"Snapshot=t46.inf", 
		EXTRARES, 
		"Url=/favicon.ico", "Referer=", ENDITEM, 
		LAST);

	web_link("K9-RT-01", 
		"Text=K9-RT-01", 
		"Snapshot=t47.inf", 
		EXTRARES, 
		"Url=/favicon.ico", "Referer=", ENDITEM, 
		LAST);

	web_link("Add to Cart_11", 
		"Text=Add to Cart", 
		"Snapshot=t48.inf", 
		EXTRARES, 
		"Url=/favicon.ico", "Referer=", ENDITEM, 
		LAST);

	lr_think_time(5);

	web_link("Return to Main Menu_11", 
		"Text=Return to Main Menu", 
		"Snapshot=t49.inf", 
		EXTRARES, 
		"Url=/favicon.ico", "Referer=", ENDITEM, 
		LAST);

	web_image("sm_dogs.gif_6", 
		"Src=/images/sm_dogs.gif", 
		"Snapshot=t50.inf", 
		EXTRARES, 
		"Url=/favicon.ico", "Referer=", ENDITEM, 
		LAST);

	web_link("K9-RT-02", 
		"Text=K9-RT-02", 
		"Snapshot=t51.inf", 
		EXTRARES, 
		"Url=/favicon.ico", "Referer=", ENDITEM, 
		LAST);

	web_link("Add to Cart_12", 
		"Text=Add to Cart", 
		"Ordinal=1", 
		"Snapshot=t52.inf", 
		EXTRARES, 
		"Url=/favicon.ico", "Referer=", ENDITEM, 
		LAST);

	web_submit_form("cart_3", 
		"Snapshot=t53.inf", 
		ITEMDATA, 
		"Name=lines[0].quantity", "Value=1", ENDITEM, 
		"Name=lines[1].quantity", "Value=1", ENDITEM, 
		"Name=lines[2].quantity", "Value=1", ENDITEM, 
		"Name=lines[3].quantity", "Value=1", ENDITEM, 
		"Name=lines[4].quantity", "Value=1", ENDITEM, 
		"Name=lines[5].quantity", "Value=1", ENDITEM, 
		"Name=lines[6].quantity", "Value=1", ENDITEM, 
		"Name=lines[7].quantity", "Value=1", ENDITEM, 
		"Name=lines[8].quantity", "Value=1", ENDITEM, 
		"Name=lines[9].quantity", "Value=1", ENDITEM, 
		"Name=lines[10].quantity", "Value=1", ENDITEM, 
		"Name=lines[11].quantity", "Value=1", ENDITEM, 
		"Name=update", "Value=Update Cart", ENDITEM, 
		EXTRARES, 
		"Url=/favicon.ico", "Referer=", ENDITEM, 
		LAST);

	web_link("Return to Main Menu_12", 
		"Text=Return to Main Menu", 
		"Snapshot=t54.inf", 
		EXTRARES, 
		"Url=/favicon.ico", "Referer=", ENDITEM, 
		LAST);

	web_image("sm_dogs.gif_7", 
		"Src=/images/sm_dogs.gif", 
		"Snapshot=t55.inf", 
		EXTRARES, 
		"Url=/favicon.ico", "Referer=", ENDITEM, 
		LAST);

	lr_think_time(6);

	web_link("K9-RT-01_2", 
		"Text=K9-RT-01", 
		"Snapshot=t56.inf", 
		EXTRARES, 
		"Url=/favicon.ico", "Referer=", ENDITEM, 
		LAST);

	web_link("Return to DOGS", 
		"Text=Return to DOGS", 
		"Snapshot=t57.inf", 
		EXTRARES, 
		"Url=/favicon.ico", "Referer=", ENDITEM, 
		LAST);

	web_link("K9-RT-02_2", 
		"Text=K9-RT-02", 
		"Snapshot=t58.inf", 
		EXTRARES, 
		"Url=/favicon.ico", "Referer=", ENDITEM, 
		LAST);

	web_link("Add to Cart_13", 
		"Text=Add to Cart", 
		"Ordinal=1", 
		"Snapshot=t59.inf", 
		EXTRARES, 
		"Url=/favicon.ico", "Referer=", ENDITEM, 
		LAST);

	lr_think_time(5);

	web_link("Return to Main Menu_13", 
		"Text=Return to Main Menu", 
		"Snapshot=t60.inf", 
		EXTRARES, 
		"Url=/favicon.ico", "Referer=", ENDITEM, 
		LAST);

	web_image("sm_dogs.gif_8", 
		"Src=/images/sm_dogs.gif", 
		"Snapshot=t61.inf", 
		EXTRARES, 
		"Url=/favicon.ico", "Referer=", ENDITEM, 
		LAST);

	web_link("K9-RT-02_3", 
		"Text=K9-RT-02", 
		"Snapshot=t62.inf", 
		EXTRARES, 
		"Url=/favicon.ico", "Referer=", ENDITEM, 
		LAST);

	web_link("Add to Cart_14", 
		"Text=Add to Cart", 
		"Ordinal=3", 
		"Snapshot=t63.inf", 
		EXTRARES, 
		"Url=/favicon.ico", "Referer=", ENDITEM, 
		LAST);

	web_link("Return to Main Menu_14", 
		"Text=Return to Main Menu", 
		"Snapshot=t64.inf", 
		EXTRARES, 
		"Url=/favicon.ico", "Referer=", ENDITEM, 
		LAST);

	web_image("sm_dogs.gif_9", 
		"Src=/images/sm_dogs.gif", 
		"Snapshot=t65.inf", 
		EXTRARES, 
		"Url=/favicon.ico", "Referer=", ENDITEM, 
		LAST);

	web_link("K9-RT-02_4", 
		"Text=K9-RT-02", 
		"Snapshot=t66.inf", 
		EXTRARES, 
		"Url=/favicon.ico", "Referer=", ENDITEM, 
		LAST);

	web_link("Add to Cart_15", 
		"Text=Add to Cart", 
		"Ordinal=4", 
		"Snapshot=t67.inf", 
		EXTRARES, 
		"Url=/favicon.ico", "Referer=", ENDITEM, 
		LAST);

	web_link("Return to Main Menu_15", 
		"Text=Return to Main Menu", 
		"Snapshot=t68.inf", 
		EXTRARES, 
		"Url=/favicon.ico", "Referer=", ENDITEM, 
		LAST);

	web_image("sm_dogs.gif_10", 
		"Src=/images/sm_dogs.gif", 
		"Snapshot=t69.inf", 
		EXTRARES, 
		"Url=/favicon.ico", "Referer=", ENDITEM, 
		LAST);

	web_link("K9-CW-01", 
		"Text=K9-CW-01", 
		"Snapshot=t70.inf", 
		EXTRARES, 
		"Url=/favicon.ico", "Referer=", ENDITEM, 
		LAST);

	web_link("Add to Cart_16", 
		"Text=Add to Cart", 
		"Ordinal=1", 
		"Snapshot=t71.inf", 
		EXTRARES, 
		"Url=/favicon.ico", "Referer=", ENDITEM, 
		LAST);

	web_link("Return to Main Menu_16", 
		"Text=Return to Main Menu", 
		"Snapshot=t72.inf", 
		EXTRARES, 
		"Url=/favicon.ico", "Referer=", ENDITEM, 
		LAST);

	web_image("sm_dogs.gif_11", 
		"Src=/images/sm_dogs.gif", 
		"Snapshot=t73.inf", 
		EXTRARES, 
		"Url=/favicon.ico", "Referer=", ENDITEM, 
		LAST);

	web_link("K9-CW-01_2", 
		"Text=K9-CW-01", 
		"Snapshot=t74.inf", 
		EXTRARES, 
		"Url=/favicon.ico", "Referer=", ENDITEM, 
		LAST);

	web_link("Add to Cart_17", 
		"Text=Add to Cart", 
		"Ordinal=2", 
		"Snapshot=t75.inf", 
		EXTRARES, 
		"Url=/favicon.ico", "Referer=", ENDITEM, 
		LAST);

	lr_end_transaction("Dogs Transaction",LR_AUTO);

	lr_think_time(10);

	web_link("Return to Main Menu_17", 
		"Text=Return to Main Menu", 
		"Snapshot=t76.inf", 
		EXTRARES, 
		"Url=/favicon.ico", "Referer=", ENDITEM, 
		LAST);

	web_image("sm_reptiles.gif", 
		"Src=/images/sm_reptiles.gif", 
		"Snapshot=t77.inf", 
		EXTRARES, 
		"Url=/favicon.ico", "Referer=", ENDITEM, 
		LAST);

	lr_think_time(16);

	lr_start_transaction("Reptiles transactin");

	web_link("RP-SN-01", 
		"Text=RP-SN-01", 
		"Snapshot=t78.inf", 
		EXTRARES, 
		"Url=/favicon.ico", "Referer=", ENDITEM, 
		LAST);

	web_link("Add to Cart_18", 
		"Text=Add to Cart", 
		"Ordinal=1", 
		"Snapshot=t79.inf", 
		EXTRARES, 
		"Url=/favicon.ico", "Referer=", ENDITEM, 
		LAST);

	web_link("Return to Main Menu_18", 
		"Text=Return to Main Menu", 
		"Snapshot=t80.inf", 
		EXTRARES, 
		"Url=/favicon.ico", "Referer=", ENDITEM, 
		LAST);

	web_image("sm_reptiles.gif_2", 
		"Src=/images/sm_reptiles.gif", 
		"Snapshot=t81.inf", 
		EXTRARES, 
		"Url=/favicon.ico", "Referer=", ENDITEM, 
		LAST);

	web_link("RP-SN-01_2", 
		"Text=RP-SN-01", 
		"Snapshot=t82.inf", 
		EXTRARES, 
		"Url=/favicon.ico", "Referer=", ENDITEM, 
		LAST);

	web_link("Add to Cart_19", 
		"Text=Add to Cart", 
		"Ordinal=2", 
		"Snapshot=t83.inf", 
		EXTRARES, 
		"Url=/favicon.ico", "Referer=", ENDITEM, 
		LAST);

	web_link("Return to Main Menu_19", 
		"Text=Return to Main Menu", 
		"Snapshot=t84.inf", 
		EXTRARES, 
		"Url=/favicon.ico", "Referer=", ENDITEM, 
		LAST);

	web_image("sm_reptiles.gif_3", 
		"Src=/images/sm_reptiles.gif", 
		"Snapshot=t85.inf", 
		EXTRARES, 
		"Url=/favicon.ico", "Referer=", ENDITEM, 
		LAST);

	web_link("Return to Main Menu_20", 
		"Text=Return to Main Menu", 
		"Snapshot=t86.inf", 
		EXTRARES, 
		"Url=/favicon.ico", "Referer=", ENDITEM, 
		LAST);

	web_image("sm_cats.gif", 
		"Src=/images/sm_cats.gif", 
		"Snapshot=t87.inf", 
		EXTRARES, 
		"Url=/favicon.ico", "Referer=", ENDITEM, 
		LAST);

	lr_think_time(4);

	web_link("FL-DSH-01", 
		"Text=FL-DSH-01", 
		"Snapshot=t88.inf", 
		EXTRARES, 
		"Url=/favicon.ico", "Referer=", ENDITEM, 
		LAST);

	lr_think_time(10);

	web_link("Return to CATS", 
		"Text=Return to CATS", 
		"Snapshot=t89.inf", 
		EXTRARES, 
		"Url=/favicon.ico", "Referer=", ENDITEM, 
		LAST);

	web_link("Return to Main Menu_21", 
		"Text=Return to Main Menu", 
		"Snapshot=t90.inf", 
		EXTRARES, 
		"Url=/favicon.ico", "Referer=", ENDITEM, 
		LAST);

	lr_end_transaction("Reptiles transactin",LR_AUTO);

	lr_end_transaction("Selecting the products",LR_AUTO);

	lr_start_transaction("Sign out transaction");

	web_link("Sign Out", 
		"Text=Sign Out", 
		"Snapshot=t91.inf", 
		EXTRARES, 
		"Url=/favicon.ico", "Referer=", ENDITEM, 
		LAST);

	lr_end_transaction("Sign out transaction",LR_AUTO);

	return 0;
}